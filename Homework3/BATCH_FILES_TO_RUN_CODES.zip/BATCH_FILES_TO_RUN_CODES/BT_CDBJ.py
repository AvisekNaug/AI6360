import PointerGenerationV5 as pg
import copy
# import pprint
import matplotlib.pyplot as plt
import numpy as np


def BT(Variables, Constraints):
    return BT1(Variables, [[], []], Constraints)


def BT1(Unlabelled, Labelled, Constraints):
    '''
    Labelled has the form: [(xyco-ordinate),(xyco-ordinate),....],[color#,color#,...]]
    Unlabelled has the form: [[(x,y),Dx=[1,2,3.. etc.]],[],[],[],...]
    Constraints has the form [[(x1,y1),(x2,y2)...],[],[],...]
    '''
    if not Unlabelled:
        return Labelled
    RemValues = [len(i[1]) for i in Unlabelled]
    _, idx = min((val, idx) for (idx, val) in enumerate(RemValues))
    # idx = 0 #RemValues.index(min(RemValues))
    X = Unlabelled[idx]  # Here X = [[(x,y),Dx=[1,2,3.. etc.]]
    for i in X[1]:
        if consistent([[X[0]] + Labelled[0], [i] + Labelled[1]], Constraints):
            newUnlabelled = Unlabelled[:idx] + Unlabelled[idx + 1:]
            newLabelled = [[X[0]] + Labelled[0], [i] + Labelled[1]]
            '''
                        Implement the domain reduction for MRV here
                        The Function would take in the currently Selected variable X and it's assigned value
                        and change the domain of values of some of the variables in Unlabelled.
            '''
            if newUnlabelled:
                newUnlabelled = CDBJ(X[0], i, newUnlabelled, Constraints)
            R = BT1(newUnlabelled, newLabelled, Constraints)
            if R != False:
                return R
    return False


def consistent(Labelled, Constraints):
    for indCons in Constraints:
        firstVar = indCons[0]
        for secondVar in indCons[1:]:
            if (firstVar in Labelled[0]) and (secondVar in Labelled[0]):
                id1 = Labelled[0].index(firstVar)
                id2 = Labelled[0].index(secondVar)
                if Labelled[1][id1] == Labelled[1][id2]:
                    return False
    return True


def CDBJ(currentVar, currentValue, newUnlabelled,
                 Constraints):  # eqvt to updataDomain(X[0],i,newUnlabelled,Constraints)
    formattedConstraints = []
    for i in Constraints:
        firstVar = i[0]
        for secondVar in i[1:]:
            formattedConstraints.append([firstVar, secondVar])

    for i in formattedConstraints:
        if (currentVar in i):
            vartoUpdate = i[1 - i.index(currentVar)]
            tempList = map(list, zip(*newUnlabelled))
            if vartoUpdate in tempList[0]:
                varIdx = tempList[0].index(vartoUpdate)
                if currentValue in tempList[1][varIdx]:
                    newUnlabelled[varIdx][1].remove(currentValue)
    return newUnlabelled


def MapPlot(ConstraintList):
    for ind in ConstraintList:
        for j in ind[1:]:
            plt.subplot(111)
            A = np.array([ind[0][0], ind[0][1]])
            B = np.array([j[0], j[1]])
            drawArrow(A, B)


def drawArrow(A, B):
    plt.arrow(A[0], A[1], B[0] - A[0], B[1] - A[1],
              head_width=0.008, length_includes_head=True)


if __name__ == "__main__":
    N = 40
    plt.figure()
    AdjList = pg.genPoints(N)
    Variables = copy.deepcopy(AdjList)
    for i in Variables:
        i.append([1, 2, 3, 4])
    ConstraintList = pg.connectPoints(AdjList, N)
    LabellingBT = BT(Variables, ConstraintList)
    print LabellingBT
    MapPlot(ConstraintList)
    ColorDict = {1: 'r', 2: 'g', 3: 'c', 4: 'b'}
    for i in xrange(N):
        plt.scatter(LabellingBT[0][i][0], LabellingBT[0][i][1], color=ColorDict[LabellingBT[1][i]])
    plt.show()