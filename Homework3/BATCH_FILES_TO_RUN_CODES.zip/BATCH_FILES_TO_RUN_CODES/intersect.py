#!/usr/bin/python

class Point:
	def __init__(self,x,y):
		self.x = x
		self.y = y

def ccw(A,B,C):
	return (C.y-A.y)*(B.x-A.x) > (B.y-A.y)*(C.x-A.x)

def intersect(A,B,C,D):
	if (A.x == D.x and A.y == D.y) or (B.x == C.x and B.y == C.y):
		return False
	else:
		return ccw(A,C,D) != ccw(B,C,D) and ccw(A,B,C) != ccw(A,B,D)

###
#a = Point(11,39)
#b = Point(77,58)
#c = Point(77,58)#Point(41,53)
#d = Point(41,53)#Point(11,39)

#print intersect(a,b,c,d)