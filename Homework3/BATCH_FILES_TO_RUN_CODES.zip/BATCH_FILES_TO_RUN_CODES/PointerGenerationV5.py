import numpy as np
import random
import math
import matplotlib.pyplot as plt
import pprint
import intersect

def genPoints(N):
    x = np.random.randint(low=1, high=100, size=N)#rand(N)
    y = np.random.randint(low=1, high=100, size=N)
    AdjList = [];
    '''
    An Adjacency List:
    AdjList[i][0]---> element itself in tuple form ;
    AdjList[i][1]--->tuple to which it connects
    for example: AdjList = [[(x,y),(a,b)],[],[],....]  there is an edge from (x,y) to (a,b)
    '''
    plt.subplot(111)
    plt.scatter(x, y,color = 'r')
    for i in xrange(N):
        AdjList.append([(x.item(i),y.item(i))])
    return AdjList

def connectPoints(AdjList,N):
    idxDictionary = {}
    fillUp = []
    Ordering = []
    randSelection = [i for i in xrange(N)]
    sinkList = {}
    for j in xrange(N):
        idxDictionary[AdjList[j][0]] = j
        fillUp.append("yes")
        Ordering.append(orderFunction(AdjList,AdjList[j]))
        sinkList[AdjList[j][0]] = []
    #print fillUp
    #pprint.pprint (Ordering)
    #for i in xrange(len(AdjList)):
    #   AdjList[i].append(Ordering[i][1][0])
    while ( "yes" in fillUp):
        idx = random.choice(randSelection)
        X = AdjList[idx]
        if fillUp[idx] == "yes":
            AdjList,fillUp,Ordering[idx],sinkList = leastDist(AdjList,idx,fillUp,Ordering[idx],X,idxDictionary,sinkList,N)
    #pprint.pprint(sinkList)
    return AdjList

def leastDist(AdjList,idx,fillUp,Ordering_X,X,directory,sinkList,N):
    success = False

    while (success==False) and (fillUp[idx]=="yes"):
        intersection = False
        currentPointer = Ordering_X[0]  # it's an index for Ordering_x[1]
        currentValue = Ordering_X[1][currentPointer]
        #print "CONSIDERING \n"
        #print [X[0],currentValue]
        #print "\n"
        if X[0] not in AdjList[directory[currentValue]]:
            #idxAdj = 0
            #valuej = 0
            for j in range(currentPointer)+ range(currentPointer+1,N-1): # xrange(currentPointer) + range(currentPointer+1,N-1)
                idxAdj = directory[Ordering_X[1][j]]
                valuej = AdjList[idxAdj][0]
                #if len(AdjList[idxAdj]) > 1:#Ekhane problem!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                #print "Hello World"
                pointsOfj = AdjList[idxAdj][1:] + sinkList[valuej]
                for k in pointsOfj:
                    a = intersect.Point(X[0][0], X[0][1])
                    b = intersect.Point(currentValue[0],currentValue[1])
                    c = intersect.Point(valuej[0],valuej[1])
                    d = intersect.Point(k[0],k[1])
                    #print ("CHECKING ")
                    #print [X[0],currentValue,valuej,k]
                    #print "\n"
                    if intersect.intersect(a,b,c,d):
                        intersection = True
                        #print [X[0],currentValue,valuej,k]
                        #print "failed \n"
                        break
                if intersection:
                    break
            #print intersection
            if not intersection:
                AdjList[idx].append(currentValue)
                #print "success and Added"
                #print [X[0],currentValue]
                success = True
                sinkList[currentValue].append(AdjList[idx][0])#X[0])
        #else:
            #print ("Already in list ")
            #print [X[0],currentValue]
            #print "\n"
        Ordering_X[0] = Ordering_X[0] + 1
        if Ordering_X[0] == len(Ordering_X[1]):
            fillUp[idx] = "no"
    return AdjList,fillUp,Ordering_X,sinkList

def orderFunction(AdjList,X):
    Ordering = []
    Distance = []
    for i in AdjList:
        if i[0] != X[0]:
            Ordering.append(i[0])
            Distance.append(math.sqrt((X[0][0] - i[0][0])**2 + (X[0][1] - i[0][1])**2))
    Ordering.sort(key=dict(zip(Ordering, Distance)).get)
    return [0]+[Ordering]

def MapPlot(ConstraintList):
     for ind in ConstraintList:
            for j in ind[1:]:
                plt.subplot(111)
                A = np.array([ind[0][0],ind[0][1]])
                B = np.array([j[0],j[1]])
                drawArrow(A,B)

def drawArrow(A, B):
    plt.arrow(A[0], A[1], B[0] - A[0], B[1] - A[1],
              head_width=0.001, length_includes_head=True)

if __name__ == "__main__":
    N = 20
    plt.figure()
    AdjList = genPoints(N)
    ConstraintList = connectPoints(AdjList,N)
    #Plotting the data for sanity check
    pprint.pprint(ConstraintList)
    MapPlot(ConstraintList)
    plt.show()