from __future__ import print_function
from __future__ import division
import re 
try: 
    input = raw_input
except NameError: 
    pass
    

class IllegalMove(Exception):
    pass


# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

class Game(object):
    '''
        Abstract class to represent a game (match) between two players.
        An instance of this class manages the history of the moves, 
        the current state of the board, and whose turn it is.
        
        Atributes:        
            self.turn :  color of the next player to move (-1 Black or +1 White)
            self.history : list of the moves playedd so far
    
    '''

    def display(self):
        '''
            Display the current state
        '''
        raise NotImplementedError # could raise a NonImplemented Exception
        
    def clone(self):
        '''
            Make a clone of this game.
            Implematation s
        '''
        raise NotImplementedError
    
    def do_move(self, m, color=None):
        '''
           Perform move 'm' 
           if color == None, 
              put a stone of color 'self.turn' 
              update self.turn
           else:
              add a stone of color 'color' but
              do not update self.turn
        '''
        raise NotImplementedError
        
    def undo_move(self):
        raise NotImplementedError
    
    def print_move(self, m):
        '''
          Print on the console the move m
        '''
        raise NotImplementedError


    def is_terminal(self):
        '''
          Return True if the game is over
                 otherwise return False
        '''
        raise NotImplementedError
    
    def legal_moves(self):
        '''
            Return the list of legal moves for the current player
        '''
        raise NotImplementedError
    
    def set_turn(self, c):
        self.turn = c
        
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
        

class Player(object):
    '''
        Abstract player class
        
        Attributes        
            self.color : -1 or +1  
            self.game : own copy of the game
    '''

    def __init__(self, game):
        self.game = game  # player's own private copy of the board

    def play(self, opp_move):
        '''
            Given 'opp_move', the last move of the opponent 
            return a move 
        '''
        raise NotImplementedError
    
    def set_color(self, c):
        self.color = c

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

class Human_hex_player(Player):
    '''
        Allow a user player to play a game at the console
        Player enters move either in format 'i' or format 'r c'
    '''

    def __init__(self, game):
        self.game = game  # player's own private copy of the board

    def play(self, opp_move):
        if opp_move is not None:
            self.game.do_move(opp_move)
        while True:
            # move is an integer specifying the index of the cell played
            m = re.findall('\d+', input("Your Move (format 'i' or 'r c') -> ") )
            if len(m) not in (1,2):
                continue
            if len(m)==2:
                m = self.game.rc2i(int(m[0]), int(m[1]))
            else:
                m = int(m[0])
            if m not in self.game.legal_moves():
                print ("Error: illegal move")
                continue
            break
        self.game.do_move(m)
        return m    

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

def play(game, player1, player2, verbose = 1):    
    # initial conditions
    last_move = None
    boardDictionary = {0:"a",1:"b",2:"c",3:"d",4:"e",5:"f",6:"g",7:"h"}
    reverseboardDictionary = {"a":0,"b":1,"c":2,"d":3,"e":4,"f":5,"g":6,"h":7,}
    if verbose:
        print ('** Player {} starts **'.format('Black' if game.turn==-1 else 'White'))  
    while not game.is_terminal():
        # get the next move from current player

        # debug
        if verbose and last_move is not None:
            print('-'*20)
            print('Last move : ',end='')
            game.print_move(last_move)

        if verbose:
            game.display()
            print ('Player {} to move '.format('BlackMCTS' if game.turn==-1 else 'WhiteHUMAN'))

        if game.turn==1:
             move = player2.play(last_move)
        else:
            x,y = boardDictionary[last_move%8], str((last_move//8)+1)
            _,_ = player1.send_command("play white "+x+y)
            _,move = player1.send_command("genmove black")
            move = (int(move[1])-1)*8 + reverseboardDictionary[move[0]]

        if move not in game.legal_moves():
            raise IllegalMove
        # update the master board
        game.do_move(move)
        last_move = move
        
    # display terminal state
    if verbose:
        print('-'*20)
        print('** Game over **')
        game.display()