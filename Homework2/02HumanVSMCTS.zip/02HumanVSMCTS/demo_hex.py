from __future__ import print_function
from __future__ import division

import game, hexgame
from gtpinterface import gtpinterface
def test_H_M():
    hg = hexgame.Hexgame(8)
    p1 = gtpinterface("rave")
    p2 = game.Human_hex_player(hg.clone())
    p2.set_color(+1)

    game.play(hg, p1, p2, verbose = 1)
    
if __name__ == "__main__":
#    test_H_H()
    print(''' 
    Black tries to connect North and South
    White tries to connect East and West
    
    Top left cell has coordinates r=0 and c=0
    ''')
    test_H_M()
